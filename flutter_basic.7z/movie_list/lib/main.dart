import 'package:flutter/material.dart';
import 'package:movie_browser/src/app.dart';

// Run the Movie Browser app
void main() => runApp(MovieBrowser());